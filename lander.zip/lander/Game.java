 import java.io.*; //everything in io

class Game {
    private static final double noBurn = 0.0;

    private static final double fullBurn = 1.0;

    private static final double deltaTime = 0.5;
    
			  
			

    private static void play(Rocket rocket ) throws RocketException , IOException/* needs throws clause */
    {	//
    	 
 			 
        while (true) 
        {
            /* read input and decide whether to burn or not */
          
            DataInputStream in = new DataInputStream(System.in);
            String line = in.readLine();
           
            
          	if (line.length()==0)
          	{
							rocket.move(deltaTime, noBurn);
          	}
          	else
          	{
          		if (line.charAt(0)=='b')
            	{
            		rocket.move(deltaTime, fullBurn); // move rocket for 0.5 second at
            		outfile.println(line);
            	// full burn
          		}
          		else
          		{
          			System.out.println("error input");
          			outfile.println("error input");
          		}
          	}
	           
            System.out.println(rocket.getHeightString());
            outfile.println(rocket.getHeightString());
        }
				
		
    }
 		public static PrintWriter outfile = null;
    public static void main(String[] args) 
    {
        /* create a planet with gravity 0.3 and surface at 0.0 */
        Planet pluto = new Planet(0.3,0.0,"pluto");
        /* create a rocket with engine strength 2.0, 20.0 units of fuel */
        Rocket rocket = new Rocket(2.0, 20.0, pluto);
        rocket.setHeight(50.0);
        
        try {
        	
  				 outfile = new PrintWriter(new FileWriter("OutFile.txt"));
 					 outfile.println("java Game:");
					 outfile.println("Press b and Enter for burn, Enter for noburn"); 
					 System.out.println("Enter b and Enter for burn, Enter for noburn"); 
           play(rocket);
            
        } catch (RocketException v) {
            System.out.println(v.getMessage());
            outfile.println(v.getMessage());
            return;
        }
        catch (IOException e) {
            //System.out.println(v.getMessage());
        }
        finally {
        	if(outfile!=null)
        	{
      			outfile.close();
      		}
      	}	
      }	
      
      
        
    
    	
    

} // end of Game class
