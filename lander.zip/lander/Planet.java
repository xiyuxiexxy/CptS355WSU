class Planet {

    private double gravity; /* units: (m/s/s) */
    private double ground;  /* units: m ,height of the surface*/
    private String name;

    /* constructors and accessors go here--you are to complete them */
      
 
    
    public Planet(double g, double h, String p) 
    {
    	gravity = g;
    	ground = h;
    	name=p;
    } 
    public double getGravity()
    {
	  	return gravity;
  	}
    public double getGround()
    {
    	return ground;
    }
    public String getName()
    {
    	return name;
    }
}
