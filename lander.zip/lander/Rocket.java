import java.text.DecimalFormat;

class Rocket {
    static final RocketException crashed = new RocketException(
            "Crashed and Burned");	//final: cannot be overridden by subclasses
    static final RocketException landed = new RocketException("Safely Landed");
    
    private double velocity = 0.0; // default to 0
    private double height = 50.0; // default to 50.0
    private Planet planet;
    private static final double safeVelocity = -1.0; // Land within this
    
    private double fuel ;
    private double engineStrength;
    
    private boolean landed()
    {
    	return (reachedSurface() && velocity > safeVelocity);
    }
    public boolean getLanded()
    {
    	return landed();
    }
    
		
		
    private boolean reachedSurface() {
        /* true if rocket is at or below the planet's surface */
        return (height<=planet.getGround());
       
    }
    public boolean getReached()
    {
    		return reachedSurface();
    }

  
    
   // engine strength 2.0, 20.0 units of fuel
    public Rocket(double strength, double f,Planet p)
    {
  		engineStrength=strength;
  		fuel=f;
  		planet=p;
  	}
    
    public void setHeight(double h)
    {
  			height=h;
  	}
    
                                                 
    private void nextHeight(double deltaTime) throws RocketException
    {
        height += (velocity * deltaTime);
        if (reachedSurface())
        {
            if (velocity <= safeVelocity) 
            {
            	throw crashed;
                /* throw crashed exception */
            } 
            else 
            {          	
            	throw landed;
                /* throw landed exception */
            }
        }
    }
    
    private void nextFuel(double burnRate,double deltaTime)
		{
				fuel-= burnRate*deltaTime;
	
		}
    
    

    private void nextVelocity(double burnRate, double deltaTime) 
    {
        velocity += ((engineStrength * burnRate) - planet.getGravity())
                * deltaTime;
    }

    public void move(double dt, double burnRate) throws RocketException
    {
        /* note that dt is measured in seconds */
        
        //if not enough fuel
        if(burnRate*dt> fuel)
        {
      			burnRate=fuel/dt;
      	}
        
        if (!reachedSurface()) 
        {
            /* update the height, velocity and fuel */
        	
            nextHeight(dt);
            nextVelocity(burnRate,dt);
            nextFuel(burnRate, dt);
        	  
        }
    }
	
	
	
	 
	  public double getHeight()
	  {
	  	return height;
		}
			
		public double getVelocity()
		{
			return velocity;
		}
		
    public String getHeightString() {
        double maxHeight = (height > 60.0) ? height : 60.0;
        double belowGround = planet.getGround() - 10.0;
        int size = (int) (maxHeight - belowGround) + 1;
        char[] buffer = new char[size];
        DecimalFormat df = new DecimalFormat(" ###.##");

        int groundPosition = (int) (planet.getGround() - belowGround); //groundPosition=10

        for (int i = 0; i < size; i++)
            buffer[i] = ' ';
        int adjustedPosition = (int) (height - belowGround);
        adjustedPosition = (adjustedPosition <= 0) ? 0 : adjustedPosition;
        /* prove here, using wp logic, that 0 <= adjustedPosition <= size-1 ?*/
        buffer[groundPosition] = '|';
        buffer[adjustedPosition] = '*';
        return (new String(buffer) + " " + df.format(velocity));
    }

		public String getState()
		{
			DecimalFormat df = new DecimalFormat(" ###.#####");
			return ("HEIGHT "+df.format(height)+" VELOCITY "+df.format(velocity)+" FUEL "+ df.format(fuel));
		}
		
		
}
